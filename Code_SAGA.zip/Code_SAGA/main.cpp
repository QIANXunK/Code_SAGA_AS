using namespace std;
#include <iostream>
#include <string>
//#include "Ridge_Regression.h"
#include "SmoothHingeLoss.h"
#include "SmoothHingeLoss_SAGA.h"
#include "SmoothHingeLoss_SPDC.h"
#include "SquaredHingeLoss.h"
#include "Ridge_Regression.h"
#include "Logistic_Regression.h"
#include "Ridge_Regression_SAGA.h"
#include "Logistic_Regression_SAGA.h"
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>






    int main(int argc,char * argv[])
    {  
            if(argc<5)  std::cerr << "try:  ./test ijcnn1 SDCA 1 100 1e-5 1" << std::endl;
            string filename=argv[1];    
            string algo=argv[2];
            long tau=atoi(argv[3]);
            long max_nb_loops=atof(argv[4]);
            double epsilon=atof(argv[5]);
            
            double lambda1=0;
            double lambda2=1e-5;
            
            if(argc>=8){
             lambda1=atof(argv[7]);
             lambda2=atof(argv[8]);
            }
         

            /*****change the path if necessary*****/
	    
	    string filenameMatrix="datas/matrix_"+filename;
	    string filenameVector="datas/vector_"+filename;
            /*****************************/
            
            
            string tau_str;
            stringstream  tau_convert;
            tau_convert<<tau;
            tau_str=tau_convert.str();
            
            string sampname;
            if(lambda2==1e-5)
             sampname="Logistic_"+filename+"tau"+tau_str+"lambda-5";
            else
             sampname="Logistic_"+filename+"tau"+tau_str;
            
           if (algo.compare("SDCA") == 0)
           {
            if(lambda2==0) std::cerr << "To run SDCA, lambda2 must be positive " << argv[0] << " NAME" << std::endl;

            /*****Below is an example using Logistic Loss function. Smooth Hinge Loss and Least square Loss can also be solved.*****/
            Logistic_Regression<long,double> sl_sdca(filenameMatrix.c_str(),lambda1/lambda2);
            long n=sl_sdca.get_n();
	    long d=sl_sdca.get_d();
            long i;
            if(argc>=6) i=atoi(argv[6]);
            else
                i=min(max((1e6+0.0)/n/tau,10.),max_nb_loops*0.1);
            sl_sdca.set_print_every_N(i);
            vector<double> w0_h(d,0);
	    vector<double> alpha0_h(n,0.0);
            if(tau>1)
              sl_sdca.SDCA(alpha0_h,w0_h,sampname,lambda2,1.,epsilon,max_nb_loops,tau,1,1,1);
            else
                sl_sdca.SDCA(alpha0_h,w0_h,sampname,lambda2,1.,epsilon,max_nb_loops,tau,1,1,1);
                sl_sdca.SDCA(alpha0_h,w0_h,sampname,lambda2,1.,epsilon,max_nb_loops,tau,1,0,1);
           }else if(algo.compare("SAGA") == 0)
           {
            
            Logistic_Regression_SAGA<long,double> sl_Log_saga(filenameMatrix.c_str(),lambda1);
            
	    long n=sl_Log_saga.get_n();
	    long d=sl_Log_saga.get_d();
            long i;
            if(argc>=6) i=atoi(argv[6]);
            else
                i=min(max((1e6+0.0)/n/tau,10.),max_nb_loops*0.1);
            sl_Log_saga.set_print_every_N(i);
            vector<double> w0_h(d,0);
	    vector<double> alpha0_h(n,0.0);
            sl_Log_saga.SAGA(alpha0_h,w0_h,sampname,1.,lambda2,epsilon,max_nb_loops,tau,1,1,1);
            sl_Log_saga.SAGA(alpha0_h,w0_h,sampname,1.,lambda2,epsilon,max_nb_loops,tau,1,0,1);
           }

	   
	 
    }
