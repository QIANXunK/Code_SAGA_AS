#ifndef SQUAREDHINGELOSS
#define SQUAREDHINGELOSS
#include <math.h>  //fabs
#include <algorithm>   //max
#include "Primal_Dual.h"



/*
The optimization problem to solve is:

           \frac{1}{n}\sum_{i=1}^n \phi_i(A_i^{\top} w)+\lambda g(w)
Assumption 1: For each i, \phi_i is 1/\gamma-smooth
Assumption 2: g is 1-strongly convex

(Note that normally for Hinge Loss type function, the loss is \phi_i(b_iA_i^{\top} w)), thus we multiply the vector A_i by b_i in the constructor.)

*/

/*
The Loss function is the squared Hingle Loss function:

                   if(x\leq 1)
                       \phi_i(x)=\frac{(x-1)^2}{2\gamma};
                   else
                       \phi_i(x)=0.

Note that \phi_i  is 1/\gamma-smooth
 
The dual loss function \phi_i^* is then:
 
                   if (x\leq 0)
                      \phi_i^*(x)=x+gamma*x^2/2 ;
                  else
                      \phi_i^ *(x)=+\infty 
*/

/*
 g is the L_1+L_2 regularizer:
                       g(w)=\frac{1}{2}\|w\|^2+\sigma\|w\|_1
                       g^*(x)=\frac{1}{2}\sum_{i=1}^d [(|x_i|-\sigma)_+]^2
                       \nabla_j g^*(x)=sign(x_i)[|x_i|-sigma]_+
 If \sigma=0, g is the L_2 regularizer.
*/

template<typename L, typename D>
class SquaredHingeLoss: public Primal_Dual<L, D> {
  
  
  
  public:
   
  D sigma;               // L_1-L_2 regularizer parameter;
  
  vector<D> vauxi;
  
  D invlamban;
  
  SquaredHingeLoss(const char* matrix_file, const char* vector_file, D sig)
  :Primal_Dual<L,D>(matrix_file,vector_file)
  {
    sigma=sig;
     for(L i=0;i<this->nsamples;i++)
     {
       for (L k = this->ptr[i]; k < this->ptr[i + 1];k++) {
        this->A[k]*=this->b[i];
      }
     }

  }
  
  SquaredHingeLoss(const char* matrix_file, D sig)
  :Primal_Dual<L,D>(matrix_file)
  {
    
    sigma=sig;
     for(L i=0;i<this->nsamples;i++)
     {
       for (L k = this->ptr[i]; k < this->ptr[i + 1];k++) {
        this->A[k]*=this->b[i];
      }
     }
    
 
    
    
  }
  
  
  inline void set_auxiliary_v(){
    
  }
  
  inline D compute_delta_alpha(D alphai, D AiTnablag, L i){
    //cout<< setprecision(20)<<" f "<<1.0/(this->v[i]+this->gamma*(this->lambda*this->nsamples))<<endl;
    D vi=this->v[i];
    if(alphai>=(AiTnablag-1)/vi)
    return (-this->gamma*alphai*this->lambdan+1-AiTnablag)/(this->gamma*this->lambdan+vi);
    else return -alphai;
  }
  
   inline D value_of_phi_i(D x, L i) {
      if(x<=1) return (x-1)*(x-1)/2/this->gamma;
      else  return 0;
    }
  
   inline D gradient_of_phi_i(D x, L i){
      if(x<=1) return (x-1)/this->gamma;
      else return 0;
    }
    
    inline D value_of_phistar_i(D x, L i) {
      if(x<=0) return x+this->gamma/2*x*x;
      else if(x>0&&x<=1e-10) return 0;                      //for rounding errors;
      else return 1.0/0.0;
    }
    
    
    
    inline D gradient_of_gstar_j(D x, L j){
      return ((x>0)-(x<0))*(max(fabs(x)-sigma,0.0));
    }
    
    inline D value_of_g_j(D x, L j){
     return x*x/2+sigma*fabs(x);     
    }
    
    inline D value_of_gstar(vector<D> & x){
     D res=0;
     L l=x.size();
     D ip=0;
     for(L i=0;i<l;i++)
     {
       ip=max(fabs(x[i])-sigma,0.0);
       res+=ip*ip;
     }
     return res/2;
    }
    
    
    
   
    
    
    
    
    
    
   
   
};

#endif /* SQUAREDHINGELOSS */