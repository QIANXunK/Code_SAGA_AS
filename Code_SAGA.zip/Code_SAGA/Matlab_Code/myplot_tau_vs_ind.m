
close all;


problems={'Logistic'};
filenames={'ijcnn1','w8a','a9a'};
   


    for f=1:length(filenames)
        filename=filenames{f};
        for pr=1:length(problems)
            problem=problems{pr};
         
    
         
        %close all;
        figure('Units','inches','Position',[0.1,0.5,3.5,4.5],'PaperPositionMode','auto');

        %subplot(length(l1),length(l2),(i-1)*length(l2)+j);


method1='SAGA-IP';
plotfile2_tau_vs_ind(filename, problem, method1,1);
plotfile2_tau_vs_ind(filename, problem, method1,10);
plotfile2_tau_vs_ind(filename, problem, method1,50);

method2='SAGA-UNI';
plotfile2_tau_vs_ind(filename, problem, method2,1);
plotfile2_tau_vs_ind(filename, problem, method2,10);
plotfile2_tau_vs_ind(filename, problem, method2,50);

%legends={'GD','FISTA','AdapAPG','AdaAGC','AdaRES'};
legends={[method1, '\tau=1'], [method1, '\tau=10'], [method1, '\tau=50'],[method2, '\tau=1'],[method2, '\tau=10'], [method2, '\tau=50']};

[hleg1, hobj1] = legend(legends);
textobj = findobj(hobj1, 'type', 'text');
set(hleg1, 'Interpreter', 'latex', 'fontsize', 10);
set(textobj,'fontsize',10);
legend1=legend(legends);
set( gca                       , ...
    'FontName'   , 'Helvetica' );

set(legend1,'Location','northeast','FontSize',10);
set(gca,'fontsize',10);




 

% if(length(filename)>8)
% title([filename(1:8) ';  {\lambda_1}=', num2str(ll1),';  {\mu_0}=',num2str(mu0) ]);
% else
% title([filename ';  {\lambda_1}=', num2str(ll1),';  {\mu_0}=',num2str(mu0) ]);
% end


xlabel('epoch');


ylabel('primal dual gap')
h=['myplots/', filename   'vs_IND.eps'];


    
print(h,'-depsc2');
            end
    end
      
  

