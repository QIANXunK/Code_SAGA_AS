function plotfile2_saga_vs_pcdm(filename, problem, method)


hold on;

lw=3;


    switch method
    case 'SAGA'
         lins='-';
        mark='none';
        color='b';
        lw=4;
        facecolor=[.75 .75 1];
        case 'APPROXMU'
         mark='none';
         lins='-.';
        color='r';
        facecolor=[.7 .7 .7];
    case 50
        lins='none';
         mark='s';
        color='r';
        facecolor=[.7 .7 .7];
        
    end
  name=['../results/', method, '_',  problem, '_',filename,'tau1','uniform'];

name
h=dlmread(name);

size(h,1)
size(h,2)


px=1:size(h,1);
px=1:10:size(h,1);

hp=plot(h(px,1),h(px,2));

min(abs(h(:,2)))
set(gca, 'YScale', 'log');
ylim([0, 1 ]);
xlim([0,1000]);

set(hp                           , ...
  'LineStyle'       , lins      , ...
  'Marker'          , mark       , ...
  'Color'           , color , 'LineWidth'       , lw,'MarkerFaceColor' , facecolor );


end






 







