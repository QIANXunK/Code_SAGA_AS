function plotfile2(filename, problem, method,L1, L2,S,pi)


hold on;

lw=3;

switch method
    case 'SPDC'
        lins='-';
        mark='p';
        color='c';
        lw=4;
        facecolor=[.75 .75 1];        
    case 'SDCA'
        lins=':';
        mark='^';
        color=[0 .5 .0];
        facecolor=[.7 .7 .7];
    case 'SAGA'
        lins='-.';
        mark='none';
        color='r';
        facecolor=[.7 .7 .7];
    case 'GD'
        lins='-';
mark='p';
color='c';
lw=4;
facecolor=[.75 .75 1];
    case 'AdaAPGXiaoLin'
lins=':';
mark='^';
color=[0 .5 .0];
facecolor=[.7 .7 .7];
    case 'AdaADGLiuYang'
lins='-.';
mark='none';
color='r';
facecolor=[.7 .7 .7];
 case 'AdaRESTART'


end


for i1=1:length(L1)
    l1=L1(i1);
    for i2=1:length(L2)
        l2=L2(i2);
for i=1:length(S)
  name=['../results/', method, '_',  problem,filename,'lambda_',num2str(l1),'gamma_', num2str(l2), 'sigma_',num2str(S(i)), 'c1tau1a1uniform'    ];

name
h=dlmread(name);

size(h,1)
size(h,2)

lh=floor(size(h,1));

plotscale=floor(linspace(1,lh,20));


hp=plot(h(plotscale,pi),h(plotscale,2));

min(abs(h(plotscale,2)))
set(gca, 'YScale', 'log');
ylim([min(abs(h(:,2))), 1 ]);
xlim([0,min(size(h,1),1000)]);

set(hp                           , ...
  'LineStyle'       , lins      , ...
  'Marker'          , mark       , ...
  'Color'           , color , 'LineWidth'       , lw,'MarkerFaceColor' , facecolor );


end
    end
end





% legend1=legend(method);
% set(legend1,'Location','northoutside');
% xlabel('time');
% ylabel('log of primal dual gap');
% %title(['dataset=' filename '    n=300, m=49749, nnz(A)=579586']);
% %title(['dataset=' filename     ' n=100000, m=800, nnz(A)=72776']);
% title(['dataset=' filename 'method=' method]);
