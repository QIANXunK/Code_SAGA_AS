
close all;


problems={'Logistic'};
filenames={'ijcnn1'};

methods={'SAGA','SDCA'};    


    for f=1:length(filenames)
        filename=filenames{f};
        for pr=1:length(problems)
            problem=problems{pr};
            for pm=1:length(methods);
                method=methods{pm};
    
         name=['../results/', method, '_',  problem, '_',filename,'tau',num2str(1),'lambda-5uniform'];

        %close all;
        figure('Units','inches','Position',[0.1,0.5,3.5,4.5],'PaperPositionMode','auto');

        %subplot(length(l1),length(l2),(i-1)*length(l2)+j);



plotfile2_tau(filename, problem, method,1);
plotfile2_tau(filename, problem, method,10);
plotfile2_tau(filename, problem, method,50);

%legends={'GD','FISTA','AdapAPG','AdaAGC','AdaRES'};
legends={[method, '\tau=1'],[method, '\tau=10'], [method, '\tau=50']};

[hleg1, hobj1] = legend(legends);
textobj = findobj(hobj1, 'type', 'text');
set(hleg1, 'Interpreter', 'latex', 'fontsize', 10);
set(textobj,'fontsize',10);
legend1=legend(legends);
set( gca                       , ...
    'FontName'   , 'Helvetica' );

set(legend1,'Location','northeast','FontSize',10);
set(gca,'fontsize',10);




 

% if(length(filename)>8)
% title([filename(1:8) ';  {\lambda_1}=', num2str(ll1),';  {\mu_0}=',num2str(mu0) ]);
% else
% title([filename ';  {\lambda_1}=', num2str(ll1),';  {\mu_0}=',num2str(mu0) ]);
% end


xlabel('epoch');


ylabel('primal dual gap')
h=['myplots/', filename , method, 'tau_nice.eps'];


    
print(h,'-depsc2');
            end
        end
end
      
  

