function plotfile2_tau(filename, problem, method,Tau)


hold on;

lw=3;




for i1=1:length(Tau)
    tau=Tau(i1);
    switch tau
    case 1
         lins='-';
        mark='none';
        color='c';
        lw=4;
        facecolor=[.75 .75 1];
        case 10
         mark='none';
         lins='-.';
        color=[0 .5 .0];
        facecolor=[.7 .7 .7];
    case 50
        lins='none';
         mark='s';
        color='r';
        facecolor=[.7 .7 .7];
        
    end
    scalep=40;
   switch method
       case 'SAGA'
  
   color='b';
       case 'SDCA'
           scalep=300;
            color='r';
   end
   name=['../results/', method, '_',  problem, '_',filename,'tau',num2str(tau),'lambda-5uniform'];
name
h=dlmread(name);

size(h,1)
size(h,2)


px=1:size(h,1);

plotlength=3000;
 
 
 switch filename
 
    case 'ijcnn1'
        switch tau
           case 1
             scalep=2;
            case 10
                scalep=10;
            case 50
                scalep=10;
        end
         plotlength=200;
end
    
    px=1:scalep:size(h,1);

hp=plot(h(px,1),h(px,2));

min(abs(h(:,2)))
set(gca, 'YScale', 'log');
ylim([0, 1 ]);
xlim([0,plotlength]);

set(hp                           , ...
  'LineStyle'       , lins      , ...
  'Marker'          , mark       , ...
  'Color'           , color , 'LineWidth'       , lw,'MarkerFaceColor' , facecolor );


end

 


end




