
close all;


problems={'Logistic'};
filenames={'ijcnn1','w8a','a9a'};

    
    for f=1:length(filenames)
        filename=filenames{f};
        for pr=1:length(problems)
            problem=problems{pr};
    
        
        %close all;
        figure('Units','inches','Position',[0.1,0.5,8.5,3.5],'PaperPositionMode','auto');

        %subplot(length(l1),length(l2),(i-1)*length(l2)+j);



plotfile2_uni_nonuni(filename, problem, 'SDCA','uniform');
plotfile2_uni_nonuni(filename, problem, 'SDCA','nonuniform');
plotfile2_uni_nonuni(filename, problem, 'SAGA','uniform');
plotfile2_uni_nonuni(filename, problem, 'SAGA','nonuniform');


%legends={'GD','FISTA','AdapAPG','AdaAGC','AdaRES'};
legends={'SDCA','IP-SDCA','SAGA','IP-SAGA'};

[hleg1, hobj1] = legend(legends);
textobj = findobj(hobj1, 'type', 'text');
set(hleg1, 'Interpreter', 'latex', 'fontsize', 10);
set(textobj,'fontsize',10);
legend1=legend(legends);
set( gca                       , ...
    'FontName'   , 'Helvetica' );

set(legend1,'Location','northeast','FontSize',10);
set(gca,'fontsize',10);




 

% if(length(filename)>8)
% title([filename(1:8) ';  {\lambda_1}=', num2str(ll1),';  {\mu_0}=',num2str(mu0) ]);
% else
% title([filename ';  {\lambda_1}=', num2str(ll1),';  {\mu_0}=',num2str(mu0) ]);
% end


xlabel('epoch');


ylabel('log(norm of gradient step)')
h=['myplots/', filename   'IP.eps'];


    
print(h,'-depsc2');
    end
end
      
  

