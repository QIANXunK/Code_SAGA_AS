#ifndef PRIMAL_DUAL_H
#define PRIMAL_DUAL_H

#include "problem_data.h"


#include <string>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <stdio.h>      /* printf */
#include <time.h>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <ctime>
template<typename L, typename D>
class Primal_Dual: public problem_data<L, D>
{


private:

  // involved variables



  std::vector<D> primal_w;

  std::vector<D> dual_alpha;  // this is alpha/lambdan in Quartz paper

  std::vector<D> baralpha;   // baralpha=sum_{i=1}^{nsamples} dual_alpha[i]*A_i

  std::vector<D> last_update;

  std::vector<D> proba_vector;

  std::vector<D> primal_u;    // this is the auxiliary variable u in ASDCA

  std::vector<D> last_update_i;

  D theta;

  // auxiliary variables

  L nb_of_iters_per_loop;

  D thetaoverpi;

  D oneminustheta;

  D current_ratio;

  L current_nb_iters;

  D primal_value;

  D dual_value;

  D epsilon;

  L max_nb_loops;

  D max_p;

  D maxv;

  D sumv;

  D last_delta;

  D total_w_updated;

  L tau;  //number of threads on each node/computer

  vector<L> batch_i;
  vector<D> batch_deltaalphai;

  L print_every_N;

std::vector<D> sampled;


  std::vector<D> norms;




protected:
  std::vector<D> v;
  D lambdan;

  string uniform;

public:

  int option;
  gsl_rng * rng;
  virtual inline D gradient_of_phi_i(D, L){return D(NULL);}
  virtual inline D gradient_of_gstar_j(D, L){return D(NULL);}
  virtual inline D value_of_phi_i(D, L) {return D(NULL);}
  virtual inline D value_of_g_j(D, L){return D(NULL);}
  virtual inline D value_of_phistar_i(D,L) {return D(NULL);}
  virtual inline D value_of_gstar(vector<D> &){return D(NULL);}
  virtual inline D compute_delta_alpha(D,D,L){return D(NULL);}
  virtual inline void set_auxiliary_v(){}
  virtual inline D compute_just_in_time_prox_grad(D, D, D, L,L){return D(NULL);}



  Primal_Dual(const char* matrix_file, const char* vector_file)
  : problem_data<L,D>(matrix_file, vector_file)
  {

  }

  Primal_Dual(const char* matrix_file)
  : problem_data<L,D>(matrix_file)
  {

  }

  void set_rng()
  {
    gsl_rng_env_setup();
    const gsl_rng_type * T;
    T = gsl_rng_default;
    rng = gsl_rng_alloc(T);
    // gsl_rng_set(rng,time(NULL));
    gsl_rng_set(rng, 27432042);

  }




  void set_v()
  {
    maxv=0;
    D minv=1000;
    v.resize(this->nsamples,0);
    norms.resize(this->nsamples,0);
    sumv=0;
    L sumw=0;
    L maxw=0;
    L minw=this->nsamples;
    for(L j=0;j<this->nfeatures;j++)
    {
      sumw+=this->w[j];
      maxw=max(maxw,this->w[j]);
      minw=min(minw,this->w[j]);

    }
    cout<<"sumw="<<sumw<<";  maxw="<<maxw<<"; minw="<<minw<<endl;
    for(L i=0;i<this->nsamples;i++)
    {
      D vi=0;
      D vi1=0;
      for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
      {
        L j=this->row_idx[k];
        vi+=(1+(this->w[j]-1)*(tau-1.0)/(this->noverc-1.0)+((tau+0.0)/this->noverc-(tau-1.0)/(this->noverc-1.0))*(1.0-1.0/this->wprime[j])*this->w[j])*this->A[k]*this->A[k];
        vi1+=1*this->A[k]*this->A[k];
        if(vi<0){cout<<vi<<" "<<" wprime "<<this->wprime[j]<<endl;break; }
      }
      norms[i]=vi1;
      //if(i%2000==0) cout<<vi/vi1<<" ";
      v[i]=vi;
      //cout<<vi/vi1<<endl;
      sumv+=vi;
      if(maxv<vi) maxv=vi;
      if(minv>vi) minv=vi;
    }
    cout<<endl;
    cout<<"  max of v: "<<maxv<<"  min of v: "<<minv<<" sumofv: "<<sumv<<endl;
  }

  void set_optimal_probability()
  {
    proba_vector.resize(this->nsamples,0);
    D sum=0;
    for(L i=0; i<this->nsamples;i++)
    {
      proba_vector[i]=v[i]/(0.0+lambdan*this->gamma)+1;
      sum+=proba_vector[i];
    }
    max_p=0;
    for(L i=0; i<this->nsamples;i++)
    {
      proba_vector[i]=proba_vector[i]/sum;
      if(max_p<proba_vector[i])
      max_p=proba_vector[i];
    }
    theta=lambdan*this->gamma/(sumv+this->gamma*lambdan*this->nsamples);
    cout<<"optimal theta: "<<theta<<endl;
    cout<<"uniform theta: "<<lambdan*this->gamma/(maxv*this->nsamples+this->gamma*lambdan*this->nsamples);
  }

  void set_uniform_probability()
  {
    proba_vector.clear();
    proba_vector.resize(this->nsamples,(tau*this->c+0.0)/this->nsamples);
    max_p=(tau*this->c+0.0)/this->nsamples;
  }


  inline L sampling(L n)
  {
    //L i=(floor)(gsl_rng_uniform(rng)*n);
    L i=gsl_rng_uniform_int(rng, n);
    if(this->c==1&&this->tau==1)
    {
      D y=gsl_rng_uniform(rng);
      while(y*max_p>proba_vector[i])
      {
        i=(floor)(gsl_rng_uniform(rng)*n);
        y=gsl_rng_uniform(rng);
      }
    }
    return i;
  }



  void update_baralpha()
  {

    for(L i_t=0;i_t<this->c;i_t++)
    for(L i_bt=0;i_bt<tau;i_bt++)
    {
      L i=batch_i[i_t*tau+i_bt];
      D deltaalphai=batch_deltaalphai[i_t*tau+i_bt];
      
    dual_alpha[i]+=deltaalphai;
    for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
    {
      L j=this->row_idx[k];
      baralpha[j]+=deltaalphai*this->A[k];
    }
  }
}

void update_baralpha(L  i, D deltaalphai)
{
  for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
  {
    L j=this->row_idx[k];
    baralpha[j]+=deltaalphai*this->A[k];
  }
}


D compute_AiTw(L i)
{
  D res=0;
  for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
  {
    L j=this->row_idx[k];
    if(current_nb_iters!=last_update_i[j])
    {
      //D p=current_ratio/last_update[j];
      D p=pow(oneminustheta,current_nb_iters-last_update_i[j]);
      D gradient=gradient_of_gstar_j(baralpha[j],j);
      primal_w[j]=p*primal_w[j]+((1-p)*gradient);
    }
    res+=this->A[k]*primal_w[j];
    last_update[j]=current_ratio;
    last_update_i[j]=current_nb_iters;
  }
  return res;
}







D compute_AiT_gradient(L i)
{
  D res=0;
  total_w_updated+=this->ptr[i + 1]-this->ptr[i];
  for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
  {

    L j=this->row_idx[k];
    D p=current_ratio/last_update[j];
    D gradient=gradient_of_gstar_j(baralpha[j],j);
    primal_w[j]=p*primal_w[j]+(p==1?0:(1-p)*gradient);
    res+=this->A[k]*gradient;
    last_update_i[j]=current_nb_iters;
    last_update[j]=current_ratio;
  }

  return res;
}


D compute_AiT_gradient_sdca(L i)
{
  total_w_updated+=this->ptr[i + 1]-this->ptr[i];
  D res=0;
  for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
  {
    L j=this->row_idx[k];
    primal_w[j]=gradient_of_gstar_j(baralpha[j],j);
    res+=this->A[k]*primal_w[j];
  }
  return res;
}

void compute_dual_value()
{
  D res=0;
  for(L i=0;i<this->nsamples;i++)
  {
    res-=value_of_phistar_i(-dual_alpha[i]*lambdan,i);

  }
  res=res/this->nsamples;

  res-=this->lambda*value_of_gstar(baralpha);
  dual_value= res;
}

void compute_primal_value()
{
  D res=0;
  for(L i=0;i<this->nsamples;i++)
  {
    D aitw=compute_AiTw( i);
    res+=value_of_phi_i(aitw,i);
  }
  res=res/this->nsamples;
  D res2=0;
  for(L j=0; j<this->nfeatures; j++)
  {
    D p=current_ratio/last_update[j];
    primal_w[j]=p*primal_w[j]+(p==1?0:(1-p)*gradient_of_gstar_j(baralpha[j],j));
    last_update[j]=1.0;
    last_update_i[j]=current_nb_iters;
    D gj=value_of_g_j(primal_w[j],j);
    res2+=gj;
  }
  current_ratio=1.0;
  primal_value= res+res2*this->lambda;
}






void compute_primal_value_sdca()
{
  D res=0;
  for(L i=0;i<this->nsamples;i++)
  {
    D aitw=compute_AiT_gradient_sdca(i);
    res+=value_of_phi_i(aitw,i);
  }
  res=res/this->nsamples;
  D res2=0;
  for(L j=0; j<this->nfeatures; j++)
  {
    primal_w[j]=gradient_of_gstar_j(baralpha[j],j);
    D gj=value_of_g_j(primal_w[j],j);
    res2+=gj;
  }
  primal_value= res+res2*this->lambda;
}

void compute_initial_primal_value()
{
  D res=0;
  for(L j=0; j<this->nfeatures; j++)
  {
    primal_w[j]=gradient_of_gstar_j(baralpha[j],j);
    D gj=value_of_g_j(primal_w[j],j);
    res+=this->lambda*gj;
  }
  D res2=0;
  for(L i=0;i<this->nsamples;i++)
  {
    D aitw=0;
    for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
    {
      L j=this->row_idx[k];
      aitw+=this->A[k]*primal_w[j];
    }
    res2+=value_of_phi_i(aitw,i);
  }
  res=res+res2/this->nsamples;
  primal_value= res;
}







void initialize(vector<D> & x0, vector<D> & w0, D val_lambda, D val_gamma, D val_epsilon, L max_nb, L nb_tau, L nb_c, L u, L agg)
{
  cout<<"start initializing"<<endl;
  this->distributed_set_up(nb_c);
  cout<<"finish in"<<endl;
  if(nb_tau>this->noverc) perror("tau should be less than n over c");
  tau=nb_tau;
  nb_of_iters_per_loop=floor(this->nsamples/(this->c*(tau+0.0)));

  batch_i.clear();
  batch_deltaalphai.clear();
  batch_i.resize(nb_tau*nb_c);
  batch_deltaalphai.resize(nb_tau*nb_c);
  sampled.clear();
  sampled.resize(this->nsamples,0);
  /**setup parameters**/
  this->set_lambda_and_gamma(val_lambda, val_gamma);
  lambdan=this->lambda*this->nsamples;
  epsilon=val_epsilon;
  max_nb_loops=max_nb;

  set_v();
  set_auxiliary_v();
  set_rng();

  /**setup probability**/
  if(tau*this->c>1)
  {
    this->set_uniform_probability();
    this->uniform="uniform";
  }
  else if(u==1)
  {
    this->set_uniform_probability();
    this->uniform="uniform";
  }
  else if(u==0)
  {
    this->set_optimal_probability();
    this->uniform="nonuniform";
  }
  


  primal_w=w0;
  dual_alpha=x0;
  primal_u.resize(this->nfeatures);

  //read_w0();

  baralpha.clear();
  baralpha.resize(this->nfeatures,0);
  last_update.clear();
  last_update.resize(this->nfeatures,1.0);
  last_update_i.clear();
  last_update_i.resize(this->nfeatures,0);
  theta=1;
  D lambdanfake=lambdan;//sqrt(this->nsamples);
  
  for(L i=0;i<this->nsamples;i++)
  {
    D st=proba_vector[i]*lambdanfake*this->gamma/(v[i]+lambdanfake*this->gamma);
    if (theta>st) theta=st;
    update_baralpha(i, dual_alpha[i]);
  }
  cout<<"theta="<<theta<<endl;



  theta=agg*theta;
  oneminustheta=1-theta;
  current_ratio=1.0;
  current_nb_iters=0;
  compute_initial_primal_value();
  compute_dual_value();
  cout<<primal_value<<endl;
  cout<<dual_value<<endl;
  cout<<"Initial primal="<<primal_w[0]<<" ;"<<" Initial dual: "<<dual_alpha[0]<<endl;
  cout<<"finished initializing"<<endl;
}


void result_record()
{
  cout<<primal_value<<endl;
  cout<<dual_value<<endl;
  cout<<primal_w[0]<<" ;"<<"dual: "<<dual_alpha[0]<<endl;
  ofstream result;
  result.open("results/w0.dat");
  for (L j=0;j<this->nfeatures;j++)
  result <<setprecision(20)<< primal_w[j] << " ";
  result << endl;
  ofstream resulta;
  resulta.open("results/alpha0.dat");
  for (L i=0;i<this->nsamples;i++)
  resulta << setprecision(20)<<dual_alpha[i] << " ";
  resulta << endl;
  result.close();
}











void batch_sampling()
{
    L i=sampling(this->nsamples);
    for(L it_b=0;it_b<this->c;it_b++)
    for(L it_t=0;it_t<tau;it_t++)
    {
        while(sampled[i]==1)
         {
           i=sampling(this->nsamples);
         }
        sampled[i]=1;
        batch_i[it_b*tau+it_t]=i;
    }
    for(L it_b=0;it_b<this->c;it_b++)
    for(L it_t=0;it_t<tau;it_t++)
    {
        sampled[batch_i[it_b*tau+it_t]]=0;
    }
}

void set_print_every_N(L i){print_every_N=i;}

void SDCA(vector<D> & x0, vector<D> & w0, string filename, D val_lambda, D val_gamma, D val_epsilon, L max_nb, L nb_tau, L nb_c, L u, L agg)
{
  initialize(x0,  w0,  val_lambda, val_gamma, val_epsilon,  max_nb,  nb_tau, nb_c,  u, agg);
  cout<<"running SDCA"<<" ; "<<filename<<endl;
  string sampname="results/SDCA_"+filename+uniform;
  ofstream samp;
  samp.open(sampname.c_str());

  cout<<"theta="<<theta<<endl;
 
  D delta=primal_value-dual_value;
  L nb_loops=0;
  L nb_iters=0;

  cout<<setprecision(9)<<"initial: "<<" delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
  samp<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<" "<<delta<<endl;
  //srand48(27432042);
  srand48(time(NULL));
  
  
  while(delta>=epsilon && nb_loops<max_nb_loops)
  {
    
    if(nb_loops%print_every_N==0){
    compute_primal_value_sdca();
    compute_dual_value();
    delta=primal_value-dual_value;
    samp<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<" "<<delta<<endl;

    cout<<setprecision(15)<<"nb of epochs: "<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<";  delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
    }
    
    nb_loops++;
 
    for(L it=0;it<nb_of_iters_per_loop;it++)
    {
      batch_sampling();
      total_w_updated=0;
      for(L it_b=0;it_b<this->c;it_b++)
      for(L it_t=0;it_t<tau;it_t++)
      {
        L i=batch_i[it_b*tau+it_t];
        D aitg=compute_AiT_gradient_sdca(i);
        //D deltaalphai=compute_delta_alpha(dual_alpha[i], aitg, i);
        D deltaalphai=-theta/proba_vector[i]*(dual_alpha[i]+gradient_of_phi_i(aitg,i)/lambdan);
        batch_deltaalphai[it_b*tau+it_t]=deltaalphai;
      }
      update_baralpha();
      nb_iters++;

    if(delta<epsilon) break;
  }
      
}
cout<<setprecision(9)<<"nb_loops: "<<floor(((0.0+nb_iters)*this->c*tau/(this->nsamples)))<<";  delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
//result_record();
}







void PDSDCA(vector<D> & x0, vector<D> & w0, string filename, D val_lambda, D val_gamma, D val_epsilon, L max_nb, L nb_tau, L nb_c, L u, L agg)
{
  initialize(x0,  w0,  val_lambda, val_gamma, val_epsilon,  max_nb,  nb_tau, nb_c,  u,agg);
  string sampname="/data/zqu/pdgap"+filename+uniform;
  cout<<"running Primal dual"<<" ; "<<filename<<endl;
  ofstream samp;
  samp.open(sampname.c_str());
  cout<<"theta="<<theta<<endl;
  string thetafilename="/data/zqu/theta"+filename+uniform;
  ofstream thetafile;
  thetafile.open(thetafilename.c_str());
  thetafile<<theta<<endl;
  D delta=primal_value-dual_value;
  L nb_loops=0;
  L nb_iters=0;
  last_delta=delta;
  cout<<setprecision(9)<<"initial: "<<" delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
  srand48(27432042);
  L * order = this->new_order(this->noverc,this->c);
  samp<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<" "<<delta<<endl;

  

  while(delta>=epsilon && nb_loops<max_nb_loops)
  {
    nb_loops++;
    for(L it=0;it<nb_of_iters_per_loop;it++)
    {

      current_ratio*=oneminustheta;

      total_w_updated=0;
      batch_sampling();
      for(L it_b=0;it_b<this->c;it_b++)
      for(L it_t=0;it_t<tau;it_t++)
      {
        L i=batch_i[it_b*tau+it_t];

        //D aitg=compute_AiT_gradient(i);
        //D deltaalphai=compute_delta_alpha(dual_alpha[i], aitg,  i);
        D aitg=compute_AiTw(i);
        D deltaalphai=-theta/proba_vector[i]*(dual_alpha[i]+gradient_of_phi_i(aitg,i)/lambdan);
        batch_deltaalphai[it_b*tau+it_t]=deltaalphai;
      }
      current_nb_iters++;
      update_baralpha();
      nb_iters++;
    if(delta<epsilon) break;
  }

  compute_primal_value();
  compute_dual_value();
  delta=primal_value-dual_value;
  samp<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<" "<<delta<<endl;
  if(delta<=epsilon) samp<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<" "<<delta<<endl;
  cout<<setprecision(15)<<"nb of epochs: "<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<";  delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
}
cout<<setprecision(15)<<"nb_epochs: "<<floor(((0.0+nb_iters)*this->c*tau/(this->nsamples)))<<";  delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
//result_record();
}



};

#endif /* MIN_SMOOTH_CONVEX_H */
