#ifndef RIDGE_REGRESSION
#define RIDGE_REGRESSION


#include "Primal_Dual.h"



/*
The optimization problem to solve is:

           \frac{1}{n}\sum_{i=1}^n \phi_i(A_i^{\top} w)+\lambda g(w)
Assumption 1: For each i, \phi_i is 1/\gamma-smooth
Assumption 2: g is 1-strongly convex


*/

/*
The Loss function is the squared Loss function:

                   \phi_i(x)=\frac{1}{2\gamma}(x-b_i)^2

Note that \phi_i  is 1/\gamma-smooth
 
The dual loss function \phi_i^* is then:
                   \phi_i^*(x)=\frac{\gamma}{2}x^2+b_ix
*/

/*
 g is the L_1+L_2 regularizer:
                       g(w)=\frac{1}{2}\|w\|^2+\sigma\|w\|_1
                       g^*(x)=\frac{1}{2}\sum_{i=1}^d [(|x_i|-\sigma)_+]^2
                       \nabla_j g^*(x)=sign(x_i)[|x_i|-sigma]_+
 If \sigma=0, g is the L_2 regularizer.
*/





template<typename L, typename D>
class Ridge_Regression: public Primal_Dual<L, D> {
  
  
  
  public:
   
  
  D sigma;         // L_1-L_2 regularizer parameter;
  
  vector<D> vauxi;
  
  D invlamban;
  
  D lambda1;
  
  D lambda2;
  
 Ridge_Regression(const char* matrix_file, const char* vector_file,  D sig)
  :Primal_Dual<L,D>(matrix_file,vector_file)
  {
    sigma=sig;
  }
  
  Ridge_Regression(const char* matrix_file,  D sig)
  :Primal_Dual<L,D>(matrix_file)
  {
    sigma=sig;

  }
  
  
    inline void set_auxiliary_v(){
    vauxi.resize(this->nsamples);
    for(L i=0;i<this->nsamples;i++)
      vauxi[i]=1.0/(this->v[i]+this->gamma*(this->lambda*this->nsamples));
    invlamban=1.0/this->lambdan;
    lambda1=this->lambda*sigma;
    lambda2=this->lambda;
  }
 
  
    inline D compute_delta_alpha(D alphai, D AiTnablag, L i){
    return -(this->gamma*alphai*this->lambdan+AiTnablag-this->b[i])*vauxi[i];
  }
    
    inline D gradient_of_phi_i(D x, L i){
     return (x-this->b[i])/this->gamma;
    
    }
    
    
    inline D value_of_phi_i(D x, L i) {
      
     return (x-this->b[i])*(x-this->b[i])/2.0/this->gamma;
    }
    
    
    inline D value_of_phistar_i(D x, L i) {
     return this->gamma*x*x/2.0+this->b[i]*x;
    }
    
    
    
     inline D gradient_of_gstar_j(D x, L j){
      return ((x>0)-(x<0))*(max(fabs(x)-sigma,0.0));
    }
    
    inline D value_of_g_j(D x, L j){
     return x*x/2+sigma*fabs(x);     
    }
    
    inline D value_of_gstar(vector<D> & x){
     D res=0;
     L l=x.size();
     D ip=0;
     for(L i=0;i<l;i++)
     {
       ip=max(fabs(x[i])-sigma,0.0);
       res+=ip*ip;
     }
     return res/2;
    }
    
    
    
    
   
   
};

#endif /* RIDGE_REGRESSION */