#ifndef RIDGE_REGRESSION_SAGA
#define RIDGE_REGRESSION_SAGA


#include "Primal_Dual_SAGA.h"



/*
The optimization problem to solve is:

           \frac{1}{n}\sum_{i=1}^n \phi_i(A_i^{\top} w)+\lambda g(w)
Assumption 1: For each i, \phi_i is 1/\gamma-smooth
Assumption 2: g is 1-strongly convex


*/

/*
The Loss function is the squared Loss function:

                   \phi_i(x)=\frac{1}{2\gamma}(x-b_i)^2

Note that \phi_i  is 1/\gamma-smooth

The dual loss function \phi_i^* is then:
                   \phi_i^*(x)=\frac{\gamma}{2}x^2+b_ix
*/

/*
g is the L_1+L_2 regularizer:
g(w)=\frac{\lambda_2}{2}\|w\|^2+\lambda1\|w\|_1
* if lambda_2>0
g^*(x)=\frac{1}{2*lambda_2}\sum_{i=1}^d [(|x_i|-\lambda1)_+]^2
\nabla_j g^*(x)=sign(x_i)[|x_i|-lambda1]_+*1./lambda_2
* otherwise
*                     g^*(x)=1_{-\lambda1\leq x\leq \lambda1}
*                     \nabla g^*(x)=0 if x\in (-lambda1, lambda1); (-\infty, 0] if x=-lambda1; [0,+\infty) if x=lambda1
If \lambda1=0, g is the L_2 regularizer.
*/




template<typename L, typename D>
class Ridge_Regression_SAGA: public Primal_Dual_SAGA<L, D> {



  public:


  D lambda1;               // L_1 regularizer parameter;

  D lambda2;       // L_2 regularizer parameter

 Ridge_Regression_SAGA(const char* matrix_file, const char* vector_file,  D sig)
  :Primal_Dual_SAGA<L,D>(matrix_file,vector_file)
  {
    lambda1=sig;
    this->gamma=1;
  }

  Ridge_Regression_SAGA(const char* matrix_file,  D sig)
  :Primal_Dual_SAGA<L,D>(matrix_file)
  {
    lambda1=sig;
    this->gamma=1;

  }


    inline void set_auxiliary_v(){
    lambda2=this->mu;
  }


 inline D get_lambda1(){return lambda1;}

inline D get_lambda2(){return lambda2;}
    inline D gradient_of_phi_i(D x, L i){
     return (x-this->b[i])/this->gamma;

    }


    inline D value_of_phi_i(D x, L i) {

     return (x-this->b[i])*(x-this->b[i])/2.0/this->gamma;
    }


    inline D value_of_phistar_i(D x, L i) {
     return this->gamma*x*x/2.0+this->b[i]*x;
    }





    inline D gradient_of_gstar_j(D x, L j){
    if(lambda2>0)
    return ((x>0)-(x<0))*(max(fabs(x)-lambda1,0.0))/lambda2;
    else
    return 0;
  }

  inline D value_of_g_j(D x, L j){
    return lambda2*x*x/2+lambda1*fabs(x);
  }

    inline D value_of_gstar(vector<D> & x){

    if(lambda2>0)
    {
      D res=0;
      D ip=0;
      L l=x.size();
      for(L i=0;i<l;i++)
      {
        ip=max(fabs(x[i])-lambda1,0.0);
        res+=ip*ip;
      }
      return res/2/lambda2;
    }
    else
    {
        return 0;
    }
  }


     inline D feasible_dual(vector<D> & x){

    if(lambda2>0)
    {
        return 1;
    }
    else
    {
        D scal=1;
        L l=x.size();
        for(L i=0;i<l;i++)
            if(fabs(x[i])>lambda1)
          scal=min(lambda1/fabs(x[i]),scal);
        return scal;
    }
  }

  //We implement Section 6.2 of SPDC paper for 'just-in-time' update
  //t0 is t0+1 in the paper SPDC
  inline D compute_just_in_time_prox_grad(D tau, D u, D x, L t0,L t1){
    if(t0==t1)
      return x;
    else{
        if(lambda2>0)
        {
      D theta=1./(1+lambda2*tau);

      D new_x=0;
      if(lambda1==0){
        D p=pow(theta,t1-t0);
        new_x=p*x-(1-p)*u/lambda2;
      }
      else{
        if(x==0){
          if(lambda1+u<0){
            D p=pow(theta,t1-t0);
            new_x=p*x-(1-p)*(u+lambda1)/lambda2;
          }
          else if(u-lambda1>0){
            D p=pow(theta,t1-t0);
            new_x=p*x-(1-p)*(u-lambda1)/lambda2;
          }else{
            new_x=0;
          }
        }else if(x>0){
          if(lambda1+u<=0){
            D p=pow(theta,t1-t0);
            new_x=p*x-(1-p)*(u+lambda1)/lambda2;
          }else{
            D t=t0-log(1+lambda2*x/(lambda1+u))/log(theta);
            if(t<t1){
              L t_tmp=floor(t);
              D p=pow(theta,t_tmp-t0);
              D x_tmp=p*x-(1-p)*(u+lambda1)/lambda2;
              x_tmp=compute_one_step(tau,u,x_tmp);
              new_x=compute_just_in_time_prox_grad(tau, u,  x_tmp,  t_tmp+1, t1);
            }
            else{
              D p=pow(theta,t1-t0);
              new_x=p*x-(1-p)*(u+lambda1)/lambda2;
            }
          }

        }else if(x<0){
          new_x=-compute_just_in_time_prox_grad(tau, -u,  -x,  t0, t1);
        }

      }
      return new_x;
        }
        else{
      D new_x=0;
      if(lambda1==0){
        new_x=x-(t1-t0)*tau*u;
      }
      else{
        if(x==0){
          if(lambda1+u<0){
            new_x=x-(t1-t0)*tau*(lambda1+u);
          }
          else if(u-lambda1>0){
            new_x=x-(t1-t0)*tau*(u-lambda1);
          }else{
            new_x=0;
          }
        }else if(x>0){
          if(lambda1+u<=0){
            new_x=x-(t1-t0)*tau*(lambda1+u);
          }else{
            D t=t0+x/(lambda1+u);
            if(t<t1){
              L t_tmp=floor(t);
              D x_tmp=x-(t_tmp-t0)*tau*(lambda1+u);
              x_tmp=compute_one_step(tau,u,x_tmp);
              new_x=compute_just_in_time_prox_grad(tau, u,  x_tmp,  t_tmp+1, t1);
            }
            else{
              new_x=x-(t1-t0)*tau*(lambda1+u);
            }
          }

        }else if(x<0){
          new_x=-compute_just_in_time_prox_grad(tau, -u,  -x,  t0, t1);
        }

      }
      return new_x;
        }
    }

  };



  D compute_one_step(D tau, D u, D x){
    D new_x;
    if(x>tau*(lambda1+u))
    new_x=(x-tau*(lambda1+u))/(1+lambda2*tau);
    else if(x<tau*(u-lambda1))
    new_x=(x-tau*(u-lambda1))/(1+lambda2*tau);
    else
    new_x=0;
    return new_x;
  }





};

#endif /* RIDGE_REGRESSION_SAGA */
