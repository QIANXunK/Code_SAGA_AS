#ifndef RIDGE_REGRESSION_LOSS_H
#define RIDGE_REGRESSION_LOSS_H


#include "L_1L_2_reg.h"



/*
The optimization problem to solve is:

           \frac{1}{n}\sum_{i=1}^n \phi_i(A_i^{\top} w)+\lambda g(w)
Assumption 1: For each i, \phi_i is 1/\gamma-smooth
Assumption 2: g is 1-strongly convex


*/

/*
The Loss function is the squared Loss function:

                   \phi_i(x)=\frac{1}{2}(x-b_i)^2

Note that \phi_i  is 1-smooth

The dual loss function \phi_i^* is then:
                   \phi_i^*(x)=\frac{1}{2}x^2+b_ix
*/







template<typename L, typename D>
class Ridge_Regression_loss: public L_1L_2_reg<L, D> {


  public:




 Ridge_Regression_loss(const char* matrix_file, D val_lambda_f)
  :L_1L_2_reg<L,D>(matrix_file, val_lambda_f)
  {

  }



    inline D gradient_of_phi_j(D x, L i){
     return (x-this->data_A.b[i]);
    }


    inline D value_of_phi_j(D x, L i) {

     return (x-this->data_A.b[i])*(x-this->data_A.b[i])/2.0;
    }


    inline D value_of_phistar_i(D x, L i) {
     return x*x/2.0+this->data_A.b[i]*x;
    }

    void run_PCDM(D val_lambda1, D val_lambda2,vector<D> & x0, L val_tau, L eval, L p_N,  L max_nb, D eps, string filename){
      this->set_lambda1(val_lambda1);
      this->set_lambda2(val_lambda2);
      this->PCDM(x0, val_tau,  eval,  p_N,  max_nb,  eps,  filename);
    }

    void run_APPROX(D val_lambda1, D val_lambda2,vector<D> & x0, L val_tau, L eval, L p_N,  L max_nb, D eps, string filename){
      this->set_lambda1(val_lambda1);
      this->set_lambda2(val_lambda2);
      this->APPROX(x0, val_tau,  eval,  p_N,  max_nb,  eps,  filename);
    }

    void run_APPROX_mu(D val_lambda1, D val_lambda2,vector<D> & x0, L val_tau, D val_mu_f, D val_mu_psi, L eval, L p_N,  L max_nb, D eps, string filename){
      this->set_lambda1(val_lambda1);
      this->set_lambda2(val_lambda2);
      this->APPROX_mu(x0, val_tau,  val_mu_f,  val_mu_psi, eval,  p_N,  max_nb,  eps,  filename);
    }




};

#endif /* RIDGE_REGRESSION */
