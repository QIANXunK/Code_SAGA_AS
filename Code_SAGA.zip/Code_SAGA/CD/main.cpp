//using namespace std;
#include <iostream>
#include <string>
#include "Ridge_Regression_loss.h"
#include "Logistic_Regression_loss.h"
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>






    int main(int argc,char * argv[])
    {

        
         if(argc<5)  std::cerr << "try:  ./test ijcnn1 CD 1 100 1e-5 1" << std::endl;
            string filename=argv[1];    
            string algo=argv[2];
            long tau=atoi(argv[3]);
            long max_nb=atof(argv[4]);
            double eps=atof(argv[5]);
            
            double lambda1=0.;
            double lambda2=0.;
            
            if(argc>=8){
             lambda1=atof(argv[7]);
             lambda2=atof(argv[8]);
            }
            /*****change the path if necessary*****/
	   
	    string filenameMatrix="../datas/matrix_"+filename;
            /*****************************/


            /*****Below is an example using Logistic  Loss function. We also included least square loss****/
	    Logistic_Regression_loss<long,double> sl(filenameMatrix.c_str(),1.);
     

            string sampname3="Logistic_"+filename+"tau1uniform";
      long n=sl.get_nb_features();
      std::vector<double> x0(n);
      long eval=1;
      if(lambda2==0)
       eval=2;
      long p_N=1;
      if(argc>=6) p_N=atoi(argv[6]);
            else
                p_N=min(max((1e6+0.0)/n/tau,10.),max_nb*0.1);
   
      
      sl.run_PCDM( lambda1, lambda2, x0, tau, eval,  p_N,   max_nb,  eps, sampname3);

    }
