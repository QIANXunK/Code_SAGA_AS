#ifndef COMPOSITE_H
#define COMPOSITE_H



#include "Matrix.h"
#include "APPROX2.h"
#include <string>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <stdio.h>      /* printf */
#include <time.h>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <ctime>
#include <math.h>



// This class solves problem of the form f(x)+g(x) where f(x)=\sum_{j=1}^m lambda_f[j] \phi_j(<A_j,x>)
//and g(x)=sum_{i=1}^n g_i(x_i). We all assume thA_t each \phi_j is 1-smooth.

//The default value of lambda_f[i] is val_lambda_f/m for all i\in [m].

template<typename L, typename D>
class Composite: public APPROX2<L, D>
{
private:

  std::vector<D> Au;
  std::vector<D> Az;
  
  std::vector<D> Ax;

  std::vector<D> lambda_f;



  L m;





protected:
  Matrix<L,D> data_A;

  std::vector<D> dual_alpha;

  std::vector<D> baralpha;  //baralpha=-sum_{j=1}^m lambda_f[j]*dual_alpha[j]*A_j
public:

  virtual inline D gradient_of_phi_j(D, L){return D(NULL);}

  virtual inline D value_of_g_i(D, L){return D(NULL);}
  virtual inline D value_of_phi_j(D, L){return D(NULL);}

  virtual inline D compute_prox(D,D,D, L){return D(NULL);}

  virtual inline D feasible_dual(std::vector<D> &) {return D(NULL);}

  virtual inline D value_of_phistar_i(D,L) {return D(NULL);}
  virtual inline D value_of_gstar(vector<D> &){return D(NULL);}

  Composite(const char* Matrix_file, D val_lambda_f)
  :data_A(Matrix_file)
  {
    m=data_A.get_n();
    lambda_f.resize(m,val_lambda_f/m);
    dual_alpha.resize(m,0);
    this->n=data_A.nfeatures;
    baralpha.resize(this->n,0);
  }


  L get_nb_features(){
    return data_A.get_d();
  }


   //This function computes \nabla_i f(gamma u +z)
    inline D partial_i_of_f(L i){
      D res=0;
      for (L k = data_A.ptr_t[i]; k < data_A.ptr_t[i + 1];k++)
      {
        L j=data_A.col_idx[k];
        D tmp=lambda_f[j]*gradient_of_phi_j(this->gamma*Au[j]+Az[j], j);
        res+=data_A.A_t[k]*tmp;
      } 
      return res;
    }

   //This function computes argmin{x1 t+x2 t^2/2+g_i(x3+t)}
   //inline D compute_prox(D x1, D x2, D x3, L i){
     //return prox_operA_tor(x1,x2,x3,i);
   //}

   inline void compute_primal_value() {
     D res=0;
     for(L i=0;i<this->n;i++){
       this->x[i]=this->gamma*this->u[i]+this->z[i];
       res+=value_of_g_i(this->x[i],i);
     }
     for(L j=0;j<m;j++){
       res+=lambda_f[j]*value_of_phi_j(this->gamma*Au[j]+Az[j],j);
     }
     this->primal_value=res;
   }

   inline void compute_dual_value(){
     for(L j=0;j<m;j++){
       dual_alpha[j]=gradient_of_phi_j(this->gamma*Au[j]+Az[j], j);
     }
     for(L i=0;i<this->n;i++){
       baralpha[i]=-partial_i_of_f(i);
       //cout<<"baralpha["<<i<<"]="<<baralpha[i]<<endl;
     }
     D res=0;
     D scal=feasible_dual(baralpha);
     for(L j=0;j<m;j++)
     {
       res-=value_of_phistar_i(scal*dual_alpha[j],j)*lambda_f[j];
     }
     res-=value_of_gstar(baralpha); // should have used value_of_gstar(scal*baralpha)
     this->dual_value=res;
   }




   inline void compute_gradient_norm(){
     std::vector<D> Tx(this->n,0);
     this->do_single_step_prox(Tx);
     D res=0;
     for(L i=0;i<this->n;i++)
      res+=(Tx[i]-this->x[i])*(Tx[i]-this->x[i]);
     this->gradient_norm=sqrt(res);
   }

   inline void set_v()
   {
     this->v.resize(this->n,0);
     D maxv=0;
     D minv=std::numeric_limits<double>::max();
     D sumv=0;
     D sumvi1=0;
     L sumw=0;
     L maxw=0;
     L minw=this->n;
     this->sumofLi=0;
     for(L j=0;j<m;j++)
     {
       sumw+=data_A.w_t[j];
       maxw=max(maxw,data_A.w_t[j]);
       minw=min(minw,data_A.w_t[j]);
     }
     cout<<"sumw="<<sumw<<";  maxw="<<maxw<<"; minw="<<minw<<endl;
     for(L i=0;i<this->n;i++)
     {
       D vi=0;
       D vi1=0;
       for (L k = data_A.ptr_t[i]; k < data_A.ptr_t[i + 1];k++)
       {
         L j=data_A.col_idx[k];
         vi+=(1.+(data_A.w_t[j]-1.)*(this->tau-1.)/max(this->n-1.,1.))*data_A.A_t[k]*data_A.A_t[k]*lambda_f[j];
         vi1+=data_A.A_t[k]*data_A.A_t[k]*lambda_f[j];
       }
       this->v[i]=vi;
       
       sumv+=vi;
       sumvi1+=vi1;
       if(maxv<vi) maxv=vi;
       if(minv>vi) minv=vi;
     }
     if(this->tau==this->n){
          for(L i=0;i<this->n;i++)
              this->v[i]=sumvi1;
     }
     this->sumofLi=sumvi1;
     cout<<"  max of v: "<<maxv<<" ;  min of v: "<<minv<<" ;  sumofv: "<<sumv<<" sumofLi="<<this->sumofLi<<endl;
   }



   inline void set_p(){
     this->proba_vector.resize(this->n,(0.0+this->tau)/this->n);
     this->max_p=(0.0+this->tau)/this->n;
   }

   inline void update_z_coordinate( L i, D dz){
     this->z[i]+=dz;
     for (L k = data_A.ptr_t[i]; k < data_A.ptr_t[i + 1];k++)
     {
       L j=data_A.col_idx[k];
       Az[j]+=dz*data_A.A_t[k];
     }
   }
   
   inline void update_x_coordinate( L i, D dx){
     this->x[i]+=dx;
     for (L k = data_A.ptr_t[i]; k < data_A.ptr_t[i + 1];k++)
     {
       L j=data_A.col_idx[k];
       Ax[j]+=dx*data_A.A_t[k];
     }
   }

   inline void update_u_coordinate( L i, D du){
     this->u[i]+=du;
     for (L k = data_A.ptr_t[i]; k < data_A.ptr_t[i + 1];k++)
     {
       L j=data_A.col_idx[k];
       Au[j]+=du*data_A.A_t[k];
     }
   }

   void compute_Au(){
     for(L j=0;j<m;j++)
       for(L k = data_A.ptr[j]; k < data_A.ptr[j + 1];k++){
         L kj=data_A.row_idx[k];
         Au[j]+=this->u[kj]*data_A.A[k];
       }
   }

   void compute_Az(){
     for(L j=0;j<m;j++)
       for(L k = data_A.ptr[j]; k < data_A.ptr[j + 1];k++){
         L kj=data_A.row_idx[k];
         Az[j]+=this->z[kj]*data_A.A[k];
       }
   }

   void compute_Au(vector<D> & x0){
     for(L j=0;j<m;j++)
       for(L k = data_A.ptr[j]; k < data_A.ptr[j + 1];k++){
         L kj=data_A.row_idx[k];
         Au[j]+=x0[kj]*data_A.A[k];
       }

   }

   void compute_Az(vector<D> & x0){
     for(L j=0;j<m;j++)
       for(L k = data_A.ptr[j]; k < data_A.ptr[j + 1];k++){
         L kj=data_A.row_idx[k];
         Az[j]+=x0[kj]*data_A.A[k];
       }
   }



   void PCDM(vector<D> & x0, L val_tau, L eval, L p_N,  L max_nb, D eps, string filename){
     Au.clear();
     Au.resize(m,0);
     Az.clear();
     Az.resize(m,0);
     compute_Az(x0);
     this->APPROX_MU(x0, val_tau, 0, 0, eval, p_N, max_nb, eps, filename,0);
   }

   void APPROX(vector<D> & x0, L val_tau, L eval, L p_N,  L max_nb, D eps, string filename){
     Au.clear();
     Au.resize(m,0);
     Az.clear();
     Az.resize(m,0);
     compute_Az(x0);
     this->APPROX_MU(x0, val_tau, 0, 0, eval, p_N, max_nb, eps, filename,1);
   }

   void APPROX_mu(vector<D> & x0, L val_tau, D val_mu_f, D val_mu_psi, L eval, L p_N,  L max_nb, D eps, string filename){
     Au.clear();
     Au.resize(m,0);
     Az.clear();
     Az.resize(m,0);
     compute_Az(x0);
     this->APPROX_MU(x0, val_tau, val_mu_f, val_mu_psi, eval, p_N, max_nb, eps, filename,1);
   }



};

#endif
