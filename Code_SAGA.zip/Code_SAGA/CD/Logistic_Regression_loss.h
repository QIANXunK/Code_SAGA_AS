#ifndef LOGISTIC_REGRESSION_LOSS_H
#define LOGISTIC_REGRESSION_LOSS_H


#include "L_1L_2_reg.h"



/*
The optimization problem to solve is:

           \frac{1}{n}\sum_{i=1}^n \phi_i(A_i^{\top} w)+\lambda g(w)
Assumption 1: For each i, \phi_i is 1/\gamma-smooth
Assumption 2: g is 1-strongly convex


*/

/*
The Loss function is the Logistic Loss function:

                   \phi_i(x)=4*log(1+exp(x))

Note that \phi_i  is 1-smooth

The dual loss function \phi_i^* is then:
		    if(x\in[0,4])
                       \phi_i^*(x)=-x*log(\frac{4- x}{x})-\frac{4}{1}log(\frac{4}{4- x})
                    else
		      \phi_i^*(x)=inf
*/







template<typename L, typename D>
class Logistic_Regression_loss: public L_1L_2_reg<L, D> {


  public:




 Logistic_Regression_loss(const char* matrix_file, D val_lambda_f)
  :L_1L_2_reg<L,D>(matrix_file, val_lambda_f)
  {
    for(L i=0;i<this->data_A.nsamples;i++)
    {
      for (L k = this->data_A.ptr[i]; k < this->data_A.ptr[i + 1];k++) {
        this->data_A.A[k]*=this->data_A.b[i];
      }
    }
    for(L i=0;i<this->data_A.nfeatures;i++)
    {
      for (L k = this->data_A.ptr_t[i]; k < this->data_A.ptr_t[i + 1];k++) {
          L j=this->data_A.col_idx[k];
        this->data_A.A_t[k]*=this->data_A.b[j];
      }
    }
  }



      inline D value_of_phi_j(D x, L i) {
        if(x>=0)
           return 4*(x+log(1+exp(-x)));
       else
           return 4*log(1+exp(x));
      }



      inline D gradient_of_phi_j(D x, L i){
       return 4.0/(1.0+exp(-x));

      }




      inline D value_of_phistar_i(D x, L i) {
       if(x>0&&(x<4.0))
         return x*log((1.*x))+(4.-x)*log((4-x))-4*log(4);
       else if(x>=4.0&&x<4.0+1e-10 ) return 0.0;
       else if(x<=0&&x>-1e-10) return 0.0;
        else {cout<<setprecision(16)<<x<<endl; return 1.0/0.0;}
      }




    void run_PCDM(D val_lambda1, D val_lambda2,vector<D> & x0, L val_tau, L eval, L p_N,  L max_nb, D eps, string filename){
      this->set_lambda1(val_lambda1);
      this->set_lambda2(val_lambda2);
      this->PCDM(x0, val_tau,  eval,  p_N,  max_nb,  eps,  filename);
    }

    void run_APPROX(D val_lambda1, D val_lambda2,vector<D> & x0, L val_tau, L eval, L p_N,  L max_nb, D eps, string filename){
      this->set_lambda1(val_lambda1);
      this->set_lambda2(val_lambda2);
      this->APPROX(x0, val_tau,  eval,  p_N,  max_nb,  eps,  filename);
    }

    void run_APPROX_mu(D val_lambda1, D val_lambda2,vector<D> & x0, L val_tau, D val_mu_f, D val_mu_psi, L eval, L p_N,  L max_nb, D eps, string filename){
      this->set_lambda1(val_lambda1);
      this->set_lambda2(val_lambda2);
      this->APPROX_mu(x0, val_tau,  val_mu_f,  val_mu_psi, eval,  p_N,  max_nb,  eps,  filename);
    }




};

#endif /* RIDGE_REGRESSION */
